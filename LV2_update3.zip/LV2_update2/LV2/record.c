#include "r_macro.h"  /* System macro and standard type definition */
#include"timer.h"
#include"lcd.h"
#include "record.h"
#include "Display_record.h"
#include "scroll.h"

extern time_t time;
extern int record_time;
//extern int new_record;
extern int move;
extern time_t time_record[20];
int line;
void  record(void){
	int i;
	int t;
	if (record_time<=19) {/// case record_time<=19
	time_record[record_time].minute=time.minute;
	time_record[record_time].second=time.second;
	time_record[record_time].centisecond=time.centisecond;
	line =record_time%6 +2;
	if ((record_time>=6)&&(move==0)){
	     for (i=0; i<=5;i++){
	     Display_record(time_record[record_time+i-5],i+2,record_time+i-5);
        }
	}else if ((record_time>=6)&&(move!=0)) {
	      //  do not thing
	      }else Display_record(time_record[record_time],line,record_time);
	      
	}else { /// case record_time>19
	        //new_record=record_time;
		for (t=0;t<=18;t++){
			time_record[t]=time_record[t+1];
		}
		time_record[19].minute=time.minute;
	        time_record[19].second=time.second;
	        time_record[19].centisecond=time.centisecond;
		/// display new record
	        if (move==0){	
	        for (i=0; i<=5;i++){
	            Display_record(time_record[19+i-5],i+2,record_time+i-5);
                     }
	        }else {
		//  do not thing	
		}
		
	}
}
	

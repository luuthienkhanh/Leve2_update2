#include "r_macro.h"  /* System macro and standard type definition */
#include "timer.h"    /* Timer driver interface */
#include "lcd.h"      /* LCD driver interface */ 
char * string_shown_on_lcd[8];
extern time_t time;
extern time_change;
extern volatile int G_elapsedTime;
 void Display_timer(time_t time,int line){
	 if (time.minute<=9&&time.second<=9){
            sprintf(string_shown_on_lcd, " 0%d:0%d:%d",time.minute,time.second,time.centisecond);
            DisplayLCD(line*8, (uint8_t*)string_shown_on_lcd);
	 } else  if (time.minute<=9&&time.second>=9){
            sprintf(string_shown_on_lcd, " 0%d:%d:%d",time.minute,time.second,time.centisecond);
            DisplayLCD(line*8, (uint8_t*)string_shown_on_lcd);
	 } else{
            sprintf(string_shown_on_lcd, " %d:%d:%d",time.minute,time.second,time.centisecond);
            DisplayLCD(line*8, (uint8_t*)string_shown_on_lcd);
	 }
}
	
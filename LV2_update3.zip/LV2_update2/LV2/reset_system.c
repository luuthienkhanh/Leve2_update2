#include "lcd.h"      /* LCD driver interface */
#include "reset_system.h"
#define PAUSING 1

extern volatile int G_TimeDisplay;
extern volatile int G_elapsedTime;
extern int record_time;
extern int move;
extern int time_temp;
extern int action;

void reset_system(void){
		
	/* Clear LCD display */
	ClearLCD();
	
	/* Print message to the first & second line of LCD */
	DisplayLCD(LCD_LINE2, (uint8_t *)" 00:00:00");
	DisplayLCD1(LCD_LINE1, (uint8_t *)" Pausing... ");
	
        action=PAUSING;
	G_elapsedTime = 0;
	record_time =0;
	move=0;
	G_TimeDisplay=0;
	time_temp=200;
}

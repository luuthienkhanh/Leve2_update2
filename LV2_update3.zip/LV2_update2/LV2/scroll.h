void scroll_up(int);
void scroll_down(int);
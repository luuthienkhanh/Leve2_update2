#include "r_macro.h"  /* System macro and standard type definition */
#include "timer.h"    /* Timer driver interface */
#include "lcd.h"      /* LCD driver interface */ 
#include "Display_timer.h"
extern time_t time;
extern time_change;
extern volatile int G_elapsedTime;
  
 void Update_timer(void){
	 unsigned long i =3000*1778;
	 unsigned long k =3000*1778; 
	if (time_change==1){
	time.centisecond=(uint8_t)G_elapsedTime*10;
	if (G_elapsedTime == 10){
		time.centisecond=0;
		G_elapsedTime=0;
		time.second=time.second+1;
		if (time.second==60){
			time.second=0;
			time.minute=time.minute+1;
			if (time.minute==60){
			time.minute=0;
		}
		}
	}        
                
		Display_timer(time,1);
//		 while (i!=0) i--;
//		 i =3000*1778;
//		 while (i!=0) i--;
//		 i =3000*1778;
//		 while (i!=0) i--;
//		  i =3000*1778;
//		 while (i!=0) i--;
//		  i =3000*1778;
//		 while (i!=0) i--;
//		  i =3000*1778;
//		 while (i!=0) i--;
		
		 
	}else { Display_timer(time,1);
//		 while (k!=0) k--;
//		k =3000*1778; 
//		 while (k!=0) k--;
//		 k =3000*1778; 
//		 while (k!=0) k--;
//		  k =3000*1778; 
//		 while (k!=0) k--;
//		  k =3000*1778; 
//		 while (k!=0) k--;
//		   k =3000*1778; 
//		 while (k!=0) k--;
	
	}
	}
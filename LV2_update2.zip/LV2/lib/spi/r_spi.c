/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer *
* Copyright (C) 2014 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/
/*******************************************************************************
* File Name    : r_spi.c
* Version      : 1.0
* Description  : SPI driver implementation
******************************************************************************/
/*****************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 13.10.2014 1.00     First Release
******************************************************************************/

/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/
/* Type definition support by Code Generator */
#include "r_macro.h"
/* Serial driver support by Code Generator */
#include "r_serial.h"

/* SPI driver configuration */
#include "r_spi_config.h"
/* SPI driver interface */
#include "r_spi_if.h"
/* SPI driver private declartion */
#include "r_spi_private.h"

/******************************************************************************
Macro definitions
******************************************************************************/

/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Exported global variables (to be accessed by other files)
******************************************************************************/

/******************************************************************************
Private global variables and functions
******************************************************************************/
volatile uint8_t *g_spi_ssl_port[SPI_SSL_NUMBER];
volatile uint8_t *g_spi_ssl_port_mode[SPI_SSL_NUMBER];
uint8_t  g_spi_ssl_pin[SPI_SSL_NUMBER];
uint8_t  g_spi_ssl_active_high[SPI_SSL_NUMBER];
uint8_t  g_spi_ssl_active_per_byte[SPI_SSL_NUMBER];

uint8_t           g_spi_transfering[SPI_CH_NUMBER];
volatile uint8_t *g_spi_sending_flag[SPI_CH_NUMBER];
volatile uint8_t *g_spi_receiving_flag[SPI_CH_NUMBER];


r_csi_send_receive_t             g_csi_send_receive_func[SPI_CH_NUMBER];
r_spi_callback_t                 g_spi_callback[SPI_CH_NUMBER];
r_spi_single_transfer_callback_t g_spi_single_transfer_callback[SPI_CH_NUMBER];

/******************************************************************************
* Function Name: spi_ssl_assert
* Description  : Assert SSL pin to active state
* Arguments    : sslSelect -
*                    Selected SSL pin
* Return Value : None
******************************************************************************/
void R_SPI_Ssl_Assert(uint8_t sslSelect)
{
	if (sslSelect > SPI_SSL_USERCONTROL)
	{
		if (g_spi_ssl_active_high[sslSelect])
		{
			/* Output HIGH for selected SSL pin */
			*g_spi_ssl_port[sslSelect] |= (uint8_t)(1<<g_spi_ssl_pin[sslSelect]);
		}
		else
		{
			/* Output LOW for selected SSL pin */
			*g_spi_ssl_port[sslSelect] &= (uint8_t)(~(1<<g_spi_ssl_pin[sslSelect]));
		}
	}
} /* End of function spi_ssl_assert() */

/******************************************************************************
* Function Name: spi_ssl_clear
* Description  : Clear SSL pin to inactive state
* Arguments    : sslSelect -
*                    Selected SSL pin
* Return Value : None
******************************************************************************/
void R_SPI_Ssl_Clear(uint8_t sslSelect)
{
	if (sslSelect > SPI_SSL_USERCONTROL)
	{
		if (g_spi_ssl_active_high[sslSelect])
		{
			/* Output LOW for selected SSL pin */
			*g_spi_ssl_port[sslSelect] &= (uint8_t)(~(1<<g_spi_ssl_pin[sslSelect]));
		}
		else
		{
			/* Output HIGH for selected SSL pin */
			*g_spi_ssl_port[sslSelect] |= (uint8_t)(1<<g_spi_ssl_pin[sslSelect]);
		}
	}
} /* End of function spi_ssl_clear() */

/******************************************************************************
* Function Name: R_SPI_Init
* Description  : Initialize selected SPI channel
* Arguments    : channel -
*                    Channel number to be initialized
*                    Valid value is 0 or 1
* Return Value : pRet -
*                    Channel initialization status
*                    0: Not success
*                    1: Success
******************************************************************************/
uint8_t R_SPI_Init(uint8_t channel)
{
    uint8_t pRet = 1;
	R_SAU1_Create();
	R_CSI21_Create();
    switch (channel)
    {
        case 0:
            g_spi_sending_flag[0]             = &SPI_CH0_SENDING_FLAG;
            g_spi_receiving_flag[0]           = &SPI_CH0_RECEIVING_FLAG;
            g_csi_send_receive_func[0]        = SPI_CH0_TRANSFER;
            g_spi_single_transfer_callback[0] = spi_ch0_single_transfer_completed;
            SPI_CH0_START();
            break;
        default:
            pRet = 0;
            break;
    }

    return pRet;
} /* End of function R_SPI_Init() */

/******************************************************************************
* Function Name: R_SPI_SslInit
* Description  : Initialize slected SSL pin
* Arguments    : sslSelect -
*                    Selected SSL
*                port -
*                    Pointer of port register contains SSL pin
*                portMode -
*                    Pointer of port mode register contains SSL pin
*                pin -
*                    Pin index of SSL pin
*                activeHigh -
*                    Selected SSL pin will be active in logic HIGH level
*                    0    : SSL active LOW
*                    Not 0: SSL active HIGH
*                activePerByte -
*                    Selected SSL pin will be active per byte transfer
*                    0    : SSL active per transfer
*                    Not 0: SSL active per byte
* Return Value : pRet -
*                    SSL initialization status
*                    0: Not success
*                    1: Success
******************************************************************************/
uint8_t R_SPI_SslInit(
    uint8_t sslSelect,
    uint8_t *port,
    uint8_t *portMode,
    uint8_t pin,
    uint8_t activeHigh,
    uint8_t activePerByte)
{
    /* Return value place holder */
    uint8_t pRet = 0;
    /* Is SSL pin valid */
    if (SPI_SSL_NUMBER > sslSelect)
    {
		if (sslSelect > SPI_SSL_USERCONTROL)
		{
			/* Assign selected pin to lookup table */
			g_spi_ssl_port[sslSelect]      = port;
			g_spi_ssl_port_mode[sslSelect] = portMode;
			g_spi_ssl_pin[sslSelect]       = pin;

			/* Set SSL pin as output */
			*g_spi_ssl_port_mode[sslSelect] &= (uint8_t)(~(1 << g_spi_ssl_pin[sslSelect]));

			/* Initial SSL pin as inactive */
			R_SPI_Ssl_Clear(sslSelect);
		}

		/* SSL operation setting */
		g_spi_ssl_active_high[sslSelect]     = activeHigh;
		g_spi_ssl_active_per_byte[sslSelect] = activePerByte;

        /* Will return success */
        pRet = 1;
    }
    else
    {
        /* SSL pin is invalid, return fail */
        pRet = 0;
    }

    /* Return result */
    return pRet;
} /* End of function R_SPI_SslInit() */

/******************************************************************************
* Function Name: R_SPI_Transfer
* Description  : SPI transfer operation
* Arguments    : channel -
*                    Selected SPI channel
*                sslSelect -
*                    Selected SSL pin
*                txBuffer -
*                    Pointer to data buffer to be transmitted
*                rxBuffer -
*                    Pointer to data buffer to store received data
*                byteCount -
*                    Number of bytes to be transfered
*                timeOut -
*                    Timeout value in case the transfer operation in loop
*                callback -
*                    Callback function to be invoke when transfer completed
* Return Value : pRet -
*                    SPI transer operation result
*                    0: Not success
*                    1: Success
******************************************************************************/
uint8_t R_SPI_Transfer(
    uint8_t          channel,
    uint8_t          sslSelect,
    uint8_t const    *txBuffer,
    uint8_t* const   rxBuffer,
    uint32_t         byteCount,
    uint32_t         timeOut,
    r_spi_callback_t callback)
{
    /* Return value place holder */
    uint8_t pRet = 1;

    /* Internal used for time out counting */
    uint32_t pTimeOut = 0;
    /* Internal counter for looping operation */
    uint32_t pCounter = 0;

    /* Validate channel and SSL pin selection */
    if ((SPI_CH_NUMBER <= channel) || (SPI_SSL_NUMBER <= sslSelect))
    {
        /* Invalid channel or SSL pin, return fail */
        pRet = 0;
        return pRet;
    }


    /* Setting up callback for selected channel
     *     If SSL active per byte transfer, internal callback is assiged,
     *     callback will be called after all bytes are transfered.
     *     If SSL active per transfer, callback is assiged */
    switch (channel)
    {
        case 0:
            if (g_spi_ssl_active_per_byte[sslSelect])
            {
                SPI_CH0_SEND_END_CALLBACK = spi_ch0_single_transfer_completed;
            }
            else
            {
                SPI_CH0_SEND_END_CALLBACK = callback;
            }
            break;
        default:
            /* Invalid channel */
            break;
    }

    /* Transfer operation */
    if (g_spi_ssl_active_per_byte[sslSelect])
    {
        /* SSL active per byte, transfer 1 byte each time */
        for (pCounter = 0; pCounter < byteCount; pCounter++)
        {
            /* Active SSL pin */
            R_SPI_Ssl_Assert(sslSelect);

            /* Setting internal status for 1 byte transfer */
            g_spi_transfering[channel] = 1;

            /* Setting channel status flag */
            *g_spi_sending_flag[channel]   = 1;
            *g_spi_receiving_flag[channel] = 1;

            /* Call tranfer function */
            g_csi_send_receive_func[channel]((uint8_t *)txBuffer + pCounter, 1 , rxBuffer + pCounter);

            /* Time out incase transfer cannot be completed */
            pTimeOut = 0;
            while (pTimeOut < timeOut)
            {
                if (!(g_spi_transfering[channel]))
                {
                    break;
                }

                pTimeOut += 1;
            }

            /* Inactive SSL pin */
            R_SPI_Ssl_Clear(sslSelect);

            /* Clear interal status if timeout, return fail */
            if (pTimeOut > timeOut)
            {
                g_spi_transfering[channel]     = 0;
                *g_spi_sending_flag[channel]   = 0;
                *g_spi_receiving_flag[channel] = 0;
                pRet = 0;
                return pRet;
            }
        }
        /* All bytes transfered, call callback */
        if (callback)
        {
            callback();
        }
    }
    else
    {

		/* Active SSL pin */
		R_SPI_Ssl_Assert(sslSelect);

        /* Setting channel status flag */
        *g_spi_sending_flag[channel]   = 1;
        *g_spi_receiving_flag[channel] = 1;

        /* Call transfer function */
        g_csi_send_receive_func[channel]((uint8_t *)txBuffer, (uint16_t)byteCount, rxBuffer);

        /* Time out incase transfer cannot be completed */
        pTimeOut = 0;
        while (pTimeOut < timeOut)
        {
            if (!(*g_spi_sending_flag[channel] || *g_spi_receiving_flag[channel]))
            {
                break;
            }

            pTimeOut += 1;
        }

		/* Inactive SSL pin */
		R_SPI_Ssl_Clear(sslSelect);

        /* Clear channel status if timeout, return fail */
        if (pTimeOut > timeOut)
        {
            *g_spi_sending_flag[channel]   = 0;
            *g_spi_receiving_flag[channel] = 0;
            pRet = 0;
        }
    }

    return pRet;
} /* End of function R_SPI_Transfer() */

/******************************************************************************
* Function Name: R_SPI_IsBusy
* Description  : Check if selected SPI channel is busy
* Arguments    : channel -
*                    Channel number to be checked
*                    Valid value is 0 or 1
* Return Value : pRet -
*                    Channel status
*                    0: Not busy
*                    1: Busy
******************************************************************************/
uint8_t R_SPI_IsBusy(uint8_t channel)
{
    uint8_t pRet = 0;
    if (SPI_CH_NUMBER <= channel)
    {
        pRet = 0;
        return pRet;
    }

    if (*g_spi_sending_flag[channel] || *g_spi_receiving_flag[channel])
    {
        pRet = 1;
    }
    else
    {
        pRet = 0;
    }

    return pRet;
} /* End of function R_SPI_IsBusy() */

/******************************************************************************
* Function Name: spi_ch0_single_transfer_completed
* Description  : Internal callback used for ssl active per byte transfer
* Arguments    : none
* Return Value : none
******************************************************************************/
void spi_ch0_single_transfer_completed(void)
{
    g_spi_transfering[0] = 0;
} /* End of function spi_ch0_single_transfer_completed() */

/******************************************************************************
* Function Name: R_SPI_DummyCallback
* Description  : Dummy callback
* Arguments    : none
* Return Value : none
******************************************************************************/
void R_SPI_DummyCallback(void)
{
    /* Do nothing */
} /* End of function R_SPI_DummyCallback() */

/* End of file */


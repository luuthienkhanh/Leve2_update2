#include"delay.h"

void delay(int t){
	unsigned long i =t*1778;
	while (i!=0) i--;
}
#include "r_macro.h"  /* System macro and standard type definition */
#include "timer.h"
#include "lcd.h"    /* LCD driver interface */
#include "Actions_for_switch.h"
#include "Port.h"
#include "record.h"
#include "scroll.h"
#include "Display_record.h"

#define PAUSING 1
#define RUNNING 2
#define FIRST_RECORD 3
#define LAST_RECORD 4
#define NO_RECORD 5
#define SCROLLING 6

extern volatile int G_TimeDisplay;
extern int action;
extern int Sw;
extern time_change;
extern int record_time;
extern int move;
extern int status;
extern int time_temp;
extern time_t time_record[20];
int new_record_time;
/******************************************************************************
* Function Name: Actions_for_switchh
* Description  : Action for each switch
* Arguments    : none
* Return Value : none
******************************************************************************/
void Actions_for_switch(void) {
	    
	    switch (Sw){
		    case 1:/* Actions if Switch 1 are pressed */
	                   { 
			   if (record_time==0){
		               status=NO_RECORD;
			       G_TimeDisplay=20;
			       time_temp=40;
			    }else 
			          if ((new_record_time-move)>6){
			               move=move+1;
			               scroll_up(move);
				       }
			     
			   else {
				   status=FIRST_RECORD;
			           G_TimeDisplay=20;
				   if (action == PAUSING)
				   {
				    EI();
                                    timer_start();
				   }   
			   }
			   }
			   
			   
			   break;
	    
	            case 2: /* Actions if Switch 2 are pressed */
		           { 
			   if (record_time==0){
			   status=NO_RECORD;
			   G_TimeDisplay=20;
			   time_temp=40;
			   }else if (move>0){
				   //status=SCROLLING;
			   move=move-1;
			   scroll_down(move);
			   }else {
			           status=LAST_RECORD;
			           G_TimeDisplay=20;
				  // Display_record(time_record[record_time],record_time,record_time);
				   if (action == PAUSING)
				   {
				    EI();
                                    timer_start();
				   }
			   }
	                   }
			   break;
			   
                    case 3: /* Actions if Switch 3 are pressed */
		          {
		           if (action == PAUSING){
		           action = RUNNING;
			   if (record_time==0){
			   record_time=0;
			   }
			   time_change=1;
			   EI();
                           timer_start();
		          }
		           else if (action == RUNNING){
			   record();
			   record_time=record_time+1;
			   if (record_time<=20){
		           new_record_time=record_time;
			   }else new_record_time=20;
		          }
			  }
			   break;
		   case 4: /* Actions if Switch 1&2 are pressed */
		          {
		           if (action == RUNNING){
		           action = PAUSING;
			   time_change=0;
			   EI();
                           timer_stop();
		          }else if (action == PAUSING){
			   time_change=0;
			   EI();
			   timer_reset();
			  }
			  }
			  break;
		   
		   default : break;
	
	    }
}
